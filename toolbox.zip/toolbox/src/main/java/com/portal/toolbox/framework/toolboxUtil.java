package com.portal.toolbox.framework;

import com.portal.toolbox.framework.AbstractPage;
import com.portal.toolbox.pages.YourDetailsPage;
import cucumber.api.java.eo.Se;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;


public class toolboxUtil extends AbstractPage {
    private YourDetailsPage YourDetailsPage = new YourDetailsPage();

    public void fillYourdetails()
    {
        YourDetailsPage.waitForPageLoad();
        YourDetailsPage.carRegistrationNumberTextField().sendKeys("ABC123");
        YourDetailsPage.findCarButton().click();
        new Select( YourDetailsPage.mileageDropdown()).selectByValue("17000");
        YourDetailsPage.carValueTextbox().sendKeys("5000");
        new Select(YourDetailsPage.vehiclePurchaseDatemonthDropdown()).selectByValue("03");
        new Select(YourDetailsPage.vehiclePurchaseDateyearDropdown()).selectByValue("2011");
        new Select(YourDetailsPage.coverDateDayDropdown()).selectByValue("01");
        new Select(YourDetailsPage.coverDateMonthDropdown()).selectByValue("03");
        new Select(YourDetailsPage.coverDateYearDropdown()).selectByValue("2018");
        YourDetailsPage.aboutYouNextButton().click();
        System.out.println("URL : "+ getDriver.getCurrentUrl());
    }
}
