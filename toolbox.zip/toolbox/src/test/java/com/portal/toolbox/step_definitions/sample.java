package com.portal.toolbox.step_definitions;

import com.portal.toolbox.BaseStepDef;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import com.portal.toolbox.framework.toolboxUtil;


public class sample extends BaseStepDef {

    private toolboxUtil toolboxUtil = new toolboxUtil();

    @Given("^I launch phptravel application$")
    public void i_launch_phptravel_application() throws Throwable {

        getDriver().get(System.getProperty("ENV"));

    }

    @When("^I select travel between  London and  Thirivanthapuram select (\\d+)/(\\d+)/(\\d+) and return on (\\d+)/(\\d+)/(\\d+)$")
    public void i_select_travel_between_London_and_Thirivanthapuram_select_and_return_on(int arg1, int arg2, int arg3, int arg4, int arg5, int arg6) throws Throwable {
         toolboxUtil.fillYourdetails();
    }

    @When("^select no of passenger '(\\d+),(\\d+),(\\d+)' and click submit$")
    public void select_no_of_passenger_and_click_subm(int arg1, int arg2, int arg3) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    }

    @Then("^I should get list of available filghts for my travedate$")
    public void i_should_get_list_of_available_filghts_for_my_travedate() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    }

}
